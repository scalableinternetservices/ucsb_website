// TypeScript Exercise: Fix the errors in this file
// Run: tsc --strict --noEmit typescript_exercise.ts

function exerciseExamples() {
  // 1. Add type annotation for the parameter
  function greet(name) {
    return `Hello, ${name}!`;
  }

  // 2. Add type annotation for the return value
  function add(a, b) {
    return a + b;
  }

  // 3. Add type annotation for the variable
  const message = "Hello TypeScript!";

  // 4. Add type annotation for the array
  const numbers = [1, 2, 3, 4, 5];

  // 5. Add type annotation for the object
  const person = {
    name: "Alice",
    age: 30
  };

  // 6. Fix the type error (string vs number)
  const result = add("5", 10);

  // 7. Add type annotation for the function parameter
  function printMessage(msg) {
    console.log(msg);
  }

  return { greet, add, message, numbers, person, result, printMessage };
}
