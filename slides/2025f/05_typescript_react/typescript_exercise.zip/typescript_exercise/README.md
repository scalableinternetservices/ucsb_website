# TypeScript Exercise

## Instructions

1. Open `typescript_exercise.ts` in your editor
2. Fix all the TypeScript errors by adding proper type annotations
3. Run `tsc --strict --noEmit typescript_exercise.ts` to check for errors
4. Continue fixing errors until the TypeScript compiler shows no errors
5. Check your work against `typescript_solution.ts` when you're done

## Learning Objectives

- Understand how to run the TypeScript compiler (`tsc`)
- Learn to read and interpret TypeScript error messages
- Practice adding basic type annotations to JavaScript code
- Understand the difference between TypeScript and JavaScript

## Files

- `typescript_exercise.ts` - The file with errors to fix
- `typescript_solution.ts` - The corrected version with proper types
- `README.md` - This instruction file
