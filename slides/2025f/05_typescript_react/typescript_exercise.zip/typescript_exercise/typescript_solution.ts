// TypeScript Exercise: SOLUTION
// This file shows the corrected version with proper TypeScript types

function solutionExamples() {
  // 1. Fixed: Added type annotation for the parameter
  function greet(name: string): string {
    return `Hello, ${name}!`;
  }

  // 2. Fixed: Added type annotation for the return value
  function add(a: number, b: number): number {
    return a + b;
  }

  // 3. Fixed: Added type annotation for the variable
  const message: string = "Hello TypeScript!";

  // 4. Fixed: Added type annotation for the array
  const numbers: number[] = [1, 2, 3, 4, 5];

  // 5. Fixed: Added type annotation for the object
  const person: { name: string; age: number } = {
    name: "Alice",
    age: 30
  };

  // 6. Fixed: Fixed the type error (string vs number)
  const result: number = add(5, 10);  // Changed "5" to 5

  // 7. Fixed: Added type annotation for the function parameter
  function printMessage(msg: string): void {
    console.log(msg);
  }

  return { greet, add, message, numbers, person, result, printMessage };
}
