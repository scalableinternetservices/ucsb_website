export interface User {
  id: string;
  username: string;
  createdAt: string;
  lastActiveAt: string;
}
